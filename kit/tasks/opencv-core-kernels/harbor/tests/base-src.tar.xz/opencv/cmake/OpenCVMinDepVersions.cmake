if(NOT DEFINED MIN_VER_CMAKE)
  set(MIN_VER_CMAKE 3.13) # Debian 10
  # set(MIN_VER_CMAKE 3.10) # Visual Studio 2017 15.7
endif()
set(MIN_VER_CUDA 9.0) # CUDA 9.0 is the minimum version supporting stable C++11 compilation for device code
set(MIN_VER_CUDNN 7.5)
set(MIN_VER_CUDNNJIT 9.0)
set(MIN_VER_PYTHON3 3.2)
set(MIN_VER_ZLIB 1.2.3)
