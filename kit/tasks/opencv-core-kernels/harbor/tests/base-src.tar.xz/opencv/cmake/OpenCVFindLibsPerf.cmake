# ----------------------------------------------------------------------------
#  Detect other 3rd-party performance and math libraries
# ----------------------------------------------------------------------------

# --- TBB ---
if(WITH_TBB)
  include("${OpenCV_SOURCE_DIR}/cmake/OpenCVDetectTBB.cmake")
endif(WITH_TBB)

# --- IPP ---
if(WITH_IPP)
  include("${OpenCV_SOURCE_DIR}/cmake/OpenCVFindIPP.cmake")
  if(HAVE_IPP)
    include("${OpenCV_SOURCE_DIR}/cmake/OpenCVFindIPPIW.cmake")
    if(HAVE_IPP_IW)
      ocv_include_directories(${IPP_IW_INCLUDES})
      list(APPEND OPENCV_LINKER_LIBS ${IPP_IW_LIBRARIES})
    endif()
    ocv_include_directories(${IPP_INCLUDE_DIRS})
    list(APPEND OPENCV_LINKER_LIBS ${IPP_LIBRARIES})

    # Details: #10229
    if(ANDROID AND NOT OPENCV_SKIP_ANDROID_IPP_FIX_1)
      set(CMAKE_SHARED_LINKER_FLAGS "-Wl,--exclude-libs,libippicv.a -Wl,--exclude-libs,libippiw.a ${CMAKE_SHARED_LINKER_FLAGS}")
    elseif(ANDROID AND NOT OPENCV_SKIP_ANDROID_IPP_FIX_2)
      set(CMAKE_SHARED_LINKER_FLAGS "-Wl,-Bsymbolic ${CMAKE_SHARED_LINKER_FLAGS}")
    endif()

    if(OPENCV_FORCE_IPP_EXCLUDE_LIBS
        OR (HAVE_IPP_ICV
            AND UNIX AND NOT ANDROID AND NOT APPLE
            AND CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang|Intel"
        )
        AND NOT OPENCV_SKIP_IPP_EXCLUDE_LIBS
    )
      set(CMAKE_SHARED_LINKER_FLAGS "-Wl,--exclude-libs,libippicv.a -Wl,--exclude-libs,libippiw.a ${CMAKE_SHARED_LINKER_FLAGS}")
    endif()
  endif()
endif()

if(WITH_ARMPL)
  include("${OpenCV_SOURCE_DIR}/cmake/OpenCVFindARMPL.cmake")
  if(HAVE_ARMPL)
    message(STATUS "Using ARM Performance Libraries")
    ocv_include_directories(${ARMPL_INCLUDE_DIRS})
    add_compile_definitions(HAVE_ARMPL)
    if(WITH_OPENMP AND OpenMP_CXX_FOUND)
      list(APPEND OPENCV_LINKER_LIBS OpenMP::OpenMP_CXX)
    endif()
  else()
    message(STATUS "ARM Performance Libraries: Not found or not available")
  endif()
endif()

# --- CUDA ---
if(WITH_CUDA)
  if(ENABLE_CUDA_FIRST_CLASS_LANGUAGE)
    include("${OpenCV_SOURCE_DIR}/cmake/OpenCVDetectCUDALanguage.cmake")
  else()
    include("${OpenCV_SOURCE_DIR}/cmake/OpenCVDetectCUDA.cmake")
  endif()
  if(NOT HAVE_CUDA)
    message(WARNING "OpenCV is not able to find/configure CUDA SDK (required by WITH_CUDA).
CUDA support will be disabled in OpenCV build.
To eliminate this warning remove WITH_CUDA=ON CMake configuration option.
")
  endif()
endif(WITH_CUDA)

# --- Eigen ---
if(WITH_EIGEN AND NOT HAVE_EIGEN)
  if(NOT OPENCV_SKIP_EIGEN_FIND_PACKAGE_CONFIG)
    find_package(Eigen3 CONFIG QUIET)  # Ceres 2.0.0 CMake scripts doesn't work with CMake's FindEigen3.cmake module (due to missing EIGEN3_VERSION_STRING)
  endif()
  if(NOT Eigen3_FOUND)
    find_package(Eigen3 QUIET)
  endif()

  if(Eigen3_FOUND)
    if(TARGET Eigen3::Eigen)
      # Use Eigen3 imported target if possible
      list(APPEND OPENCV_LINKER_LIBS Eigen3::Eigen)
      set(HAVE_EIGEN 1)
    else()
      if(DEFINED EIGEN3_INCLUDE_DIRS)
        set(EIGEN_INCLUDE_PATH ${EIGEN3_INCLUDE_DIRS})
        set(HAVE_EIGEN 1)
      elseif(DEFINED EIGEN3_INCLUDE_DIR)
        set(EIGEN_INCLUDE_PATH ${EIGEN3_INCLUDE_DIR})
        set(HAVE_EIGEN 1)
      endif()
    endif()
    if(HAVE_EIGEN)
      if(DEFINED EIGEN3_WORLD_VERSION)  # CMake module
        set(EIGEN_WORLD_VERSION ${EIGEN3_WORLD_VERSION})
        set(EIGEN_MAJOR_VERSION ${EIGEN3_MAJOR_VERSION})
        set(EIGEN_MINOR_VERSION ${EIGEN3_MINOR_VERSION})
      elseif(DEFINED Eigen3_VERSION_MAJOR) # Recommended package config variables
        # see https://github.com/opencv/opencv/issues/27530
        set(EIGEN_WORLD_VERSION ${Eigen3_VERSION_MAJOR})
        set(EIGEN_MAJOR_VERSION ${Eigen3_VERSION_MINOR})
        set(EIGEN_MINOR_VERSION ${Eigen3_VERSION_PATCH})
      else()  # Deprecated package config variables
        # Removed on master at https://gitlab.com/libeigen/eigen/-/commit/f2984cd0778dd0a1d7e74216d826eaff2bc6bfab
        set(EIGEN_WORLD_VERSION ${EIGEN3_VERSION_MAJOR})
        set(EIGEN_MAJOR_VERSION ${EIGEN3_VERSION_MINOR})
        set(EIGEN_MINOR_VERSION ${EIGEN3_VERSION_PATCH})
      endif()
    endif()
  endif()

  if(NOT HAVE_EIGEN)
    if(NOT EIGEN_INCLUDE_PATH OR NOT EXISTS "${EIGEN_INCLUDE_PATH}")
      set(__find_paths "")
      set(__find_path_extra_options "")
      if(NOT CMAKE_CROSSCOMPILING)
        list(APPEND __find_paths /opt)
      endif()
      if(DEFINED ENV{EIGEN_ROOT})
        set(__find_paths "$ENV{EIGEN_ROOT}/include")
        list(APPEND __find_path_extra_options NO_DEFAULT_PATH)
      else()
        set(__find_paths ENV ProgramFiles ENV ProgramW6432)
      endif()
      find_path(EIGEN_INCLUDE_PATH "Eigen/Core"
                PATHS ${__find_paths}
                PATH_SUFFIXES include/eigen3 include/eigen2 Eigen/include/eigen3 Eigen/include/eigen2
                DOC "The path to Eigen3/Eigen2 headers"
                ${__find_path_extra_options}
      )
    endif()
    if(EIGEN_INCLUDE_PATH AND EXISTS "${EIGEN_INCLUDE_PATH}")
      ocv_parse_header("${EIGEN_INCLUDE_PATH}/Eigen/src/Core/util/Macros.h" EIGEN_VERSION_LINES EIGEN_WORLD_VERSION EIGEN_MAJOR_VERSION EIGEN_MINOR_VERSION)
      set(HAVE_EIGEN 1)
    endif()
  endif()
endif()
if(HAVE_EIGEN)
  if(EIGEN_INCLUDE_PATH AND EXISTS "${EIGEN_INCLUDE_PATH}")
    ocv_include_directories(SYSTEM ${EIGEN_INCLUDE_PATH})
  endif()
endif()


# --- Clp ---
# Ubuntu: sudo apt-get install coinor-libclp-dev coinor-libcoinutils-dev
ocv_clear_vars(HAVE_CLP)

if(WITH_CLP AND NOT ANDROID AND NOT IOS)

  # 1. Modern CMake config (vcpkg / system packages)
  find_package(Clp CONFIG QUIET)
  if(Clp_FOUND AND TARGET Coin::Clp AND TARGET Coin::CoinUtils)
    set(HAVE_CLP 1)
    list(APPEND OPENCV_LINKER_LIBS Coin::Clp Coin::CoinUtils)
  endif()

  # 2. pkg-config fallback (Unix)
  if(NOT HAVE_CLP AND UNIX)
    find_package(PkgConfig QUIET)
    if(PKG_CONFIG_FOUND)
      pkg_check_modules(CLP QUIET clp)
      if(CLP_FOUND)
        set(HAVE_CLP 1)
        ocv_include_directories(SYSTEM ${CLP_INCLUDE_DIRS})
        list(APPEND OPENCV_LINKER_LIBS ${CLP_LIBRARIES})
      endif()
    endif()
  endif()

  # 3. Manual fallback (last resort)
  if(NOT HAVE_CLP)
    find_path(CLP_INCLUDE_PATH
      NAMES coin/ClpSimplex.hpp
      PATHS /usr/include /usr/local/include /opt/include
      DOC "The path to Clp headers"
    )

    if(CLP_INCLUDE_PATH)
      # Support both:
      #   /usr/include/coin/ClpSimplex.hpp
      #   /usr/local/include/ClpSimplex.hpp + /coin
      ocv_include_directories(
        ${CLP_INCLUDE_PATH}
        "${CLP_INCLUDE_PATH}/coin"
      )

      find_library(CLP_LIBRARY
        NAMES Clp libClp
      )
      find_library(COINUTILS_LIBRARY
        NAMES CoinUtils libCoinUtils
      )

      if(CLP_LIBRARY AND COINUTILS_LIBRARY)
        set(HAVE_CLP 1)
        list(APPEND OPENCV_LINKER_LIBS
          ${CLP_LIBRARY}
          ${COINUTILS_LIBRARY}
        )
        if(UNIX)
          list(APPEND OPENCV_LINKER_LIBS m)
        endif()
      endif()
    endif()
  endif()

endif()

# --- ARM KleidiCV
if(WITH_KLEIDICV)
  if(KLEIDICV_SOURCE_PATH AND EXISTS "${KLEIDICV_SOURCE_PATH}/adapters/opencv/CMakeLists.txt")
    message(STATUS "Use external KleidiCV ${KLEIDICV_SOURCE_PATH}")
    set(HAVE_KLEIDICV ON)
  endif()
  if(NOT HAVE_KLEIDICV)
    include("${OpenCV_SOURCE_DIR}/hal/kleidicv/kleidicv.cmake")
    download_kleidicv(KLEIDICV_SOURCE_PATH)
    if(KLEIDICV_SOURCE_PATH)
      set(HAVE_KLEIDICV ON)
    endif()
  endif()
  if(HAVE_KLEIDICV AND EXISTS "${KLEIDICV_SOURCE_PATH}/LICENSES/Apache-2.0.txt")
    ocv_install_3rdparty_licenses(KleidiCV "${KLEIDICV_SOURCE_PATH}/LICENSES/Apache-2.0.txt")
  endif()
endif(WITH_KLEIDICV)

# --- FastCV ---
if(WITH_FASTCV)
  if((EXISTS ${FastCV_INCLUDE_PATH}) AND (EXISTS ${FastCV_LIB_PATH}))
    message(STATUS "Use external FastCV ${FastCV_INCLUDE_PATH}, ${FastCV_LIB_PATH}")
    find_library(FASTCV_LIBRARY NAMES "fastcv"
                 PATHS "${FastCV_LIB_PATH}" NO_DEFAULT_PATH NO_CMAKE_FIND_ROOT_PATH)
    mark_as_advanced(FASTCV_LIBRARY)
    if (FASTCV_LIBRARY)
      set(HAVE_FASTCV TRUE CACHE BOOL "FastCV status")
    else()
      set(HAVE_FASTCV FALSE CACHE BOOL "FastCV status")
    endif()
  else()
    include("${OpenCV_SOURCE_DIR}/3rdparty/fastcv/fastcv.cmake")
    set(FCV_ROOT_DIR "${OpenCV_BINARY_DIR}/3rdparty/fastcv")
    download_fastcv(${FCV_ROOT_DIR})
    if(HAVE_FASTCV)
      set(FastCV_INCLUDE_PATH "${FCV_ROOT_DIR}/inc" CACHE PATH "FastCV includes directory")
      set(FastCV_LIB_PATH "${FCV_ROOT_DIR}/libs" CACHE PATH "FastCV library directory")
      ocv_install_3rdparty_licenses(FastCV "${OpenCV_BINARY_DIR}/3rdparty/fastcv/LICENSE")
      add_library(fastcv STATIC IMPORTED)
      set_target_properties(fastcv PROPERTIES
          IMPORTED_LINK_INTERFACE_LIBRARIES "dl"
          IMPORTED_LOCATION "${FastCV_LIB_PATH}/libfastcv.a"
      )
      if (NOT BUILD_SHARED_LIBS)
        install(FILES "${FastCV_LIB_PATH}/libfastcv.a" DESTINATION "${OPENCV_3P_LIB_INSTALL_PATH}" COMPONENT "dev")
        set(FASTCV_LOCATION_PATH "${FastCV_LIB_PATH}/libfastcv.a" CACHE INTERNAL "" FORCE)
        set(FASTCV_INSTALL_PATH "${CMAKE_INSTALL_PREFIX}/${OPENCV_3P_LIB_INSTALL_PATH}/libfastcv.a" CACHE INTERNAL "" FORCE)
      endif()
      set(FASTCV_LIBRARY "fastcv" CACHE PATH "FastCV library")
      list(APPEND OPENCV_LINKER_LIBS ${FASTCV_LIBRARY})
    else()
      set(HAVE_FASTCV FALSE CACHE BOOL "FastCV status")
    endif()
  endif()
endif(WITH_FASTCV)
