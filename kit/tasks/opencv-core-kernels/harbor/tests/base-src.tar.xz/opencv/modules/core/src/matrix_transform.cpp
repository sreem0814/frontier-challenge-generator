// This file is part of OpenCV project.
// It is subject to the license terms in the LICENSE file found in the top-level directory
// of this distribution and at http://opencv.org/license.html
// Copyright (C) 2026, Advanced Micro Devices, Inc., all rights reserved.
#include "precomp.hpp"
#include "opencl_kernels_core.hpp"
#include "hal_replacement.hpp"
#include "opencv2/core/detail/dispatch_helper.impl.hpp"

#include "transpose.simd.hpp"
#include "transpose.simd_declarations.hpp"
#include "nd_copy.hpp"

#include <algorithm> // std::swap_ranges
#include <numeric> // std::accumulate

namespace cv {

////////////////////////////////////// transpose /////////////////////////////////////////

template<typename T> static void
transpose_( const uchar* src, size_t sstep, uchar* dst, size_t dstep, Size sz )
{

    int i = 0, j, m = sz.width, n = sz.height;

    for( ; i < m; i++ )
    {
        T* d0 = (T*)(dst + dstep*i);
        j = 0;
        for( ; j < n; j++ )
        {
            const T* s0 = (const T*)(src + i*sizeof(T) + j*sstep);
            d0[j] = s0[0];
        }
    }
}

template<typename T> static void
transposeI_( uchar* data, size_t step, int n )
{
    for( int i = 0; i < n; i++ )
    {
        T* row = (T*)(data + step*i);
        uchar* data1 = data + i*sizeof(T);
        for( int j = i+1; j < n; j++ )
            std::swap( row[j], *(T*)(data1 + step*j) );
    }
}

typedef void (*TransposeFunc)( const uchar* src, size_t sstep, uchar* dst, size_t dstep, Size sz );
typedef void (*TransposeInplaceFunc)( uchar* data, size_t step, int n );

#define DEF_TRANSPOSE_FUNC(suffix, type) \
static void transpose_##suffix( const uchar* src, size_t sstep, uchar* dst, size_t dstep, Size sz ) \
{ transpose_<type>(src, sstep, dst, dstep, sz); } \
\
static void transposeI_##suffix( uchar* data, size_t step, int n ) \
{ transposeI_<type>(data, step, n); }

DEF_TRANSPOSE_FUNC(8u, uchar)
DEF_TRANSPOSE_FUNC(16u, ushort)
DEF_TRANSPOSE_FUNC(8uC3, Vec3b)
DEF_TRANSPOSE_FUNC(32s, int)
DEF_TRANSPOSE_FUNC(16uC3, Vec3s)
DEF_TRANSPOSE_FUNC(32sC2, Vec2i)
DEF_TRANSPOSE_FUNC(32sC3, Vec3i)
DEF_TRANSPOSE_FUNC(32sC4, Vec4i)
DEF_TRANSPOSE_FUNC(32sC6, Vec6i)
DEF_TRANSPOSE_FUNC(32sC8, Vec8i)

static TransposeFunc transposeTab[] =
{
    0, transpose_8u, transpose_16u, transpose_8uC3, transpose_32s, 0, transpose_16uC3, 0,
    transpose_32sC2, 0, 0, 0, transpose_32sC3, 0, 0, 0, transpose_32sC4,
    0, 0, 0, 0, 0, 0, 0, transpose_32sC6, 0, 0, 0, 0, 0, 0, 0, transpose_32sC8
};

nd::TransposeFunc nd::getTransposeFunc(size_t esz)
{
    return esz < sizeof(transposeTab)/sizeof(transposeTab[0]) ? transposeTab[esz] : nullptr;
}

static TransposeInplaceFunc transposeInplaceTab[] =
{
    0, transposeI_8u, transposeI_16u, transposeI_8uC3, transposeI_32s, 0, transposeI_16uC3, 0,
    transposeI_32sC2, 0, 0, 0, transposeI_32sC3, 0, 0, 0, transposeI_32sC4,
    0, 0, 0, 0, 0, 0, 0, transposeI_32sC6, 0, 0, 0, 0, 0, 0, 0, transposeI_32sC8
};

#ifdef HAVE_OPENCL

static bool ocl_transpose( InputArray _src, OutputArray _dst )
{
    const ocl::Device & dev = ocl::Device::getDefault();
    const int TILE_DIM = 32, BLOCK_ROWS = 8;
    int type = _src.type(), cn = CV_MAT_CN(type), depth = CV_MAT_DEPTH(type),
        rowsPerWI = dev.isIntel() ? 4 : 1;

    UMat src = _src.getUMat();
    _dst.create(src.cols, src.rows, type);
    UMat dst = _dst.getUMat();

    String kernelName("transpose");
    bool inplace = dst.u == src.u;

    if (inplace)
    {
        CV_Assert(dst.cols == dst.rows);
        kernelName += "_inplace";
    }
    else
    {
        // check required local memory size
        size_t required_local_memory = (size_t) TILE_DIM*(TILE_DIM+1)*CV_ELEM_SIZE(type);
        if (required_local_memory > ocl::Device::getDefault().localMemSize())
            return false;
    }

    String deviceMacro;
    if (dev.isIntel())
        deviceMacro = " -D INTEL_GPU";
    else
        deviceMacro = "";

    ocl::Kernel k(kernelName.c_str(), ocl::core::transpose_oclsrc,
                  format("-D T=%s -D T1=%s -D cn=%d -D TILE_DIM=%d -D BLOCK_ROWS=%d -D rowsPerWI=%d%s%s",
                         ocl::memopTypeToStr(type), ocl::memopTypeToStr(depth),
                         cn, TILE_DIM, BLOCK_ROWS, rowsPerWI, inplace ? " -D INPLACE" : "", deviceMacro.c_str()));
    if (k.empty())
        return false;

    if (inplace)
        k.args(ocl::KernelArg::ReadWriteNoSize(dst), dst.rows);
    else
        k.args(ocl::KernelArg::ReadOnly(src),
               ocl::KernelArg::WriteOnlyNoSize(dst));

    size_t localsize[2]  = { TILE_DIM, BLOCK_ROWS };
    size_t globalsize[2] = { (size_t)src.cols, inplace ? ((size_t)src.rows + rowsPerWI - 1) / rowsPerWI : (divUp((size_t)src.rows, TILE_DIM) * BLOCK_ROWS) };

    if (inplace && dev.isIntel())
    {
        localsize[0] = 16;
        localsize[1] = dev.maxWorkGroupSize() / localsize[0];
    }

    return k.run(2, globalsize, localsize, false);
}

#endif

void transpose( InputArray _src, OutputArray _dst )
{
    CV_INSTRUMENT_REGION();

    int type = _src.type(), esz = CV_ELEM_SIZE(type);
    CV_Assert( _src.dims() <= 2 && esz <= 32 );

    CV_OCL_RUN(_dst.isUMat(),
               ocl_transpose(_src, _dst))

    Mat src = _src.getMat();
    if( src.empty() )
    {
        _dst.release();
        return;
    }

    _dst.create(src.cols, src.rows, src.type());
    Mat dst = _dst.getMat();

    // handle the case of single-column/single-row matrices, stored in STL vectors.
    if( src.rows != dst.cols || src.cols != dst.rows )
    {
        CV_Assert( src.size() == dst.size() && (src.cols == 1 || src.rows == 1) );
        src.copyTo(dst);
        return;
    }

    CALL_HAL(transpose2d, cv_hal_transpose2d, src.data, src.step, dst.data, dst.step, src.cols, src.rows, esz);

    if( dst.data == src.data )
    {
        TransposeInplaceFunc func = transposeInplaceTab[esz];
        CV_Assert( func != 0 );
        CV_Assert( dst.cols == dst.rows );
        func( dst.ptr(), dst.step, dst.rows );
    }
    else
    {
        TransposeFunc func = transposeTab[esz];
        CV_Assert( func != 0 );
        func( src.ptr(), src.step, dst.ptr(), dst.step, src.size() );
    }
}


void transpose(InputArray src_, const std::vector<int>& order, OutputArray dst_)
{
    CV_INSTRUMENT_REGION();

    Mat inp = src_.getMat();
    const int ndims = inp.dims;
    CV_Assert(!(ndims == 0 && inp.empty()));
    CV_CheckEQ(order.size(), static_cast<size_t>(ndims), "Number of dimensions shouldn't change");

    bool used[CV_MAX_DIM] = {false};
    int newShape[CV_MAX_DIM];
    for (int i = 0; i < ndims; i++)
    {
        int j = order[i];
        CV_Check(j, 0 <= j && j < ndims && !used[j], "New order should be a valid permutation of the old one");
        used[j] = true;
        newShape[i] = inp.size[j];
    }

    // plain 2D transpose keeps using cv::transpose (HAL, in-place square case);
    // not for an empty input, which cv::transpose would answer by releasing dst
    if (ndims == 2 && order[0] == 1 && !inp.empty() && nd::getTransposeFunc(inp.elemSize()))
    {
        transpose(inp, dst_);
        return;
    }

    dst_.create(ndims, newShape, inp.type());
    Mat out = dst_.getMat();
    if (out.total() == 0)
        return;
    nd::copy(nd::permute(nd::viewOf(inp), order.data()), nd::viewOf(out));
}

void transposeND(InputArray src, const std::vector<int>& order, OutputArray dst)
{
    transpose(src, order, dst);
}


// Generic scalar fallback
CV_ALWAYS_INLINE void flipHoriz_generic( const uchar* src, size_t sstep, uchar* dst, size_t dstep, Size size, size_t esz )
{
    int i, j, limit = (int)(((size.width + 1)/2)*esz);
    int height = size.height;
    AutoBuffer<int> _tab(size.width*esz);
    int* tab = _tab.data();

    for( i = 0; i < size.width; i++ )
        for( size_t k = 0; k < esz; k++ )
            tab[i*esz + k] = (int)((size.width - i - 1)*esz + k);

    for( ; height--; src += sstep, dst += dstep )
    {
        for( i = 0; i < limit; i++ )
        {
            j = tab[i];
            uchar t0 = src[i], t1 = src[j];
            dst[i] = t1; dst[j] = t0;
        }
    }
}

static void flipHoriz( const uchar* src, size_t sstep, uchar* dst, size_t dstep, Size size, size_t esz )
{
    // Fallback: generic scalar
    flipHoriz_generic(src, sstep, dst, dstep, size, esz);
}

static void
flipVert( const uchar* src0, size_t sstep, uchar* dst0, size_t dstep, Size size, size_t esz )
{
    const uchar* src1 = src0 + (size.height - 1)*sstep;
    uchar* dst1 = dst0 + (size.height - 1)*dstep;
    size.width *= (int)esz;

    for( int y = 0; y < (size.height + 1)/2; y++, src0 += sstep, src1 -= sstep,
                                                  dst0 += dstep, dst1 -= dstep )
    {
        int i = 0;

        if (isAligned<sizeof(int)>(src0, src1, dst0, dst1))
        {
            for( ; i <= size.width - 16; i += 16 )
            {
                int t0 = ((int*)(src0 + i))[0];
                int t1 = ((int*)(src1 + i))[0];

                ((int*)(dst0 + i))[0] = t1;
                ((int*)(dst1 + i))[0] = t0;

                t0 = ((int*)(src0 + i))[1];
                t1 = ((int*)(src1 + i))[1];

                ((int*)(dst0 + i))[1] = t1;
                ((int*)(dst1 + i))[1] = t0;

                t0 = ((int*)(src0 + i))[2];
                t1 = ((int*)(src1 + i))[2];

                ((int*)(dst0 + i))[2] = t1;
                ((int*)(dst1 + i))[2] = t0;

                t0 = ((int*)(src0 + i))[3];
                t1 = ((int*)(src1 + i))[3];

                ((int*)(dst0 + i))[3] = t1;
                ((int*)(dst1 + i))[3] = t0;
            }

            for( ; i <= size.width - 4; i += 4 )
            {
                int t0 = ((int*)(src0 + i))[0];
                int t1 = ((int*)(src1 + i))[0];

                ((int*)(dst0 + i))[0] = t1;
                ((int*)(dst1 + i))[0] = t0;
            }
        }

        for( ; i < size.width; i++ )
        {
            uchar t0 = src0[i];
            uchar t1 = src1[i];

            dst0[i] = t1;
            dst1[i] = t0;
        }
    }
}

#ifdef HAVE_OPENCL

enum { FLIP_COLS = 1 << 0, FLIP_ROWS = 1 << 1, FLIP_BOTH = FLIP_ROWS | FLIP_COLS };

static bool ocl_flip(InputArray _src, OutputArray _dst, int flipCode )
{
    CV_Assert(flipCode >= -1 && flipCode <= 1);

    const ocl::Device & dev = ocl::Device::getDefault();
    int type = _src.type(), depth = CV_MAT_DEPTH(type), cn = CV_MAT_CN(type),
            flipType, kercn = std::min(ocl::predictOptimalVectorWidth(_src, _dst), 4);

    bool doubleSupport = dev.doubleFPConfig() > 0;
    if (!doubleSupport && depth == CV_64F)
        kercn = cn;

    if (cn > 4)
        return false;

    Size size = _src.size();
    _dst.create(size, type);
    UMat src = _src.getUMat(), dst = _dst.getUMat();
    bool inplace = (dst.u == src.u);

    String kernelName;
    if (flipCode == 0)
        kernelName = "arithm_flip_rows", flipType = FLIP_ROWS;
    else if (flipCode > 0)
        kernelName = "arithm_flip_cols", flipType = FLIP_COLS;
    else
        kernelName = "arithm_flip_rows_cols", flipType = FLIP_BOTH;

    if(inplace)
        kernelName += "_inplace";

    int pxPerWIy = (dev.isIntel() && (dev.type() & ocl::Device::TYPE_GPU)) ? 4 : 1;
    kercn = (cn!=3 || flipType == FLIP_ROWS) ? std::max(kercn, cn) : cn;
    const int TILE_SIZE = 32, BLOCK_ROWS = 8;

    ocl::Kernel k(kernelName.c_str(), ocl::core::flip_oclsrc,
                format( "-D T=%s -D T1=%s -D DEPTH=%d -D cn=%d -D PIX_PER_WI_Y=%d -D kercn=%d -D TILE_SIZE=%d -D BLOCK_ROWS=%d%s",
                kercn != cn ? ocl::typeToStr(CV_MAKE_TYPE(depth, kercn)) : ocl::vecopTypeToStr(CV_MAKE_TYPE(depth, kercn)),
                kercn != cn ? ocl::typeToStr(depth) : ocl::vecopTypeToStr(depth), depth, cn, pxPerWIy, kercn, TILE_SIZE, BLOCK_ROWS,
                inplace ? " -D INPLACE" : ""));
    if (k.empty())
        return false;

    int cols = size.width * cn / kercn, rows = size.height;
    int work_cols = flipType == FLIP_COLS ? (cols + 1) >> 1 : cols;
    int work_rows = flipType & FLIP_ROWS ? (rows + 1) >> 1 : rows;

    if (inplace)
    {
        k.args(ocl::KernelArg::ReadWriteNoSize(dst), rows, cols);

        int gs_cols, gs_rows;
        if (flipType == FLIP_COLS)
        {
            gs_cols = work_cols;
            gs_rows = rows;
        }
        else if (flipType == FLIP_ROWS)
        {
            gs_cols = cols;
            gs_rows = work_rows;
        }
        else // FLIP_BOTH
        {
            gs_cols = cols;
            gs_rows = rows;
        }

        size_t globalsize[2] = {
            (size_t)divUp(gs_cols, TILE_SIZE) * TILE_SIZE,
            (size_t)divUp(gs_rows, TILE_SIZE) * BLOCK_ROWS
        };
        size_t localsize[2] = { TILE_SIZE, BLOCK_ROWS };
        return k.run(2, globalsize, localsize, false);
    }
    else
    {
        k.args(ocl::KernelArg::ReadOnlyNoSize(src),
           ocl::KernelArg::WriteOnly(dst, cn, kercn), work_rows, work_cols);

        size_t maxWorkGroupSize = dev.maxWorkGroupSize();
        CV_Assert(maxWorkGroupSize % 4 == 0);

        size_t globalsize[2] = { (size_t)work_cols, ((size_t)work_rows + pxPerWIy - 1) / pxPerWIy };
        size_t localsize[2]  = { maxWorkGroupSize / 4, 4 };
        return k.run(2, globalsize, (flipType == FLIP_COLS) && !dev.isIntel() ? localsize : NULL, false);
    }
}

#endif

void flip( InputArray _src, OutputArray _dst, int flip_mode )
{
    CV_INSTRUMENT_REGION();

    CV_Assert( _src.dims() <= 2 );
    Size size = _src.size();

    if (flip_mode < 0)
    {
        if (size.width == 1)
            flip_mode = 0;
        if (size.height == 1)
            flip_mode = 1;
    }

    if ((size.width == 1 && flip_mode > 0) ||
        (size.height == 1 && flip_mode == 0))
    {
        return _src.copyTo(_dst);
    }

    CV_OCL_RUN( _dst.isUMat(), ocl_flip(_src, _dst, flip_mode))

    Mat src = _src.getMat();
    int type = src.type();
    _dst.create( size, type );
    Mat dst = _dst.getMat();

    CALL_HAL(flip, cv_hal_flip, type, src.ptr(), src.step, src.cols, src.rows,
             dst.ptr(), dst.step, flip_mode);

    size_t esz = CV_ELEM_SIZE(type);

    if( flip_mode <= 0 )
        flipVert( src.ptr(), src.step, dst.ptr(), dst.step, src.size(), esz );
    else
        flipHoriz( src.ptr(), src.step, dst.ptr(), dst.step, src.size(), esz );

    if( flip_mode < 0 )
        flipHoriz( dst.ptr(), dst.step, dst.ptr(), dst.step, dst.size(), esz );
}

// In-place flip of a continuous array: swap the slices along the axis, no temporary copy.
static void flipNDInplace(Mat& m, int axis)
{
    size_t nouter = 1;
    for (int i = 0; i < axis; i++)
        nouter *= (size_t)m.size[i];
    const int n = m.size[axis];
    const size_t step = m.step[axis];
    uchar* data = m.ptr();
    for (size_t i = 0; i < nouter; i++, data += n*step)
        for (int j = 0, k = n - 1; j < k; j++, k--)
            std::swap_ranges(data + j*step, data + (j + 1)*step, data + k*step);
}

void flipND(InputArray _src, OutputArray _dst, int _axis)
{
    CV_INSTRUMENT_REGION();

    Mat src = _src.getMat();

    // verify axis
    int ndim = src.dims;
    CV_CheckLT(_axis, ndim, "flipND: given axis is out of range");
    CV_CheckGE(_axis, -ndim, "flipND: given axis is out of range");
    int axis = (_axis + ndim) % ndim;

    _dst.create(ndim, src.size.p, src.type());
    Mat dst = _dst.getMat();
    if (dst.data == src.data && src.isContinuous() && dst.isContinuous())
    {
        flipNDInplace(dst, axis);
        return;
    }

    nd::View v = nd::viewOf(src);
    nd::flip(v, axis);
    nd::copy(v, nd::viewOf(dst));
}

void concat(InputArrayOfArrays _src, int axis, OutputArray _dst)
{
    CV_INSTRUMENT_REGION();

    std::vector<Mat> src;
    _src.getMatVector(src);
    CV_Assert(!src.empty());

    const Mat& src0 = src[0];
    const int ndims = src0.dims, type = src0.type(), ninputs = (int)src.size();
    CV_CheckGE(ndims, 1, "concat: 0-dimensional arrays are not supported");
    CV_CheckGE(axis, -ndims, "concat: axis is out of range");
    CV_CheckLT(axis, ndims, "concat: axis is out of range");
    if (axis < 0)
        axis += ndims;

    int outShape[CV_MAX_DIM];
    for (int i = 0; i < ndims; i++)
        outShape[i] = src0.size[i];
    int64 axisSize = 0;
    for (int k = 0; k < ninputs; k++)
    {
        const Mat& m = src[k];
        CV_CheckEQ(m.type(), type, "concat: all the input arrays must have the same type");
        CV_CheckEQ(m.dims, ndims, "concat: all the input arrays must have the same number of dimensions");
        for (int i = 0; i < ndims; i++)
            if (i != axis)
                CV_CheckEQ(m.size[i], outShape[i], "concat: the input shapes must match except along the axis");
        axisSize += m.size[axis];
    }
    CV_CheckLE((size_t)axisSize, (size_t)INT_MAX, "concat: the output is too big");
    outShape[axis] = (int)axisSize;

    _dst.create(ndims, outShape, type);
    Mat dst = _dst.getMat();

    AutoBuffer<nd::View, 4> sv(ninputs), dv(ninputs);
    const nd::View dst0 = nd::viewOf(dst);
    int ofs = 0;
    for (int k = 0; k < ninputs; k++)
    {
        const int sz = src[k].size[axis];
        sv[k] = nd::viewOf(src[k]);
        dv[k] = dst0;
        nd::slice(dv[k], axis, ofs, 1, sz);
        ofs += sz;
    }
    nd::copyBatch(sv.data(), dv.data(), ninputs);
}

void split(InputArray _src, int axis, const std::vector<int>& sizes, OutputArrayOfArrays _dst)
{
    CV_INSTRUMENT_REGION();

    Mat src = _src.getMat();
    const int ndims = src.dims, type = src.type(), noutputs = (int)sizes.size();
    CV_CheckGE(ndims, 1, "split: 0-dimensional arrays are not supported");
    CV_CheckGE(axis, -ndims, "split: axis is out of range");
    CV_CheckLT(axis, ndims, "split: axis is out of range");
    if (axis < 0)
        axis += ndims;
    CV_Assert(noutputs > 0);

    int64 axisSize = 0;
    for (int k = 0; k < noutputs; k++)
    {
        CV_CheckGE(sizes[k], 0, "split: the sizes must be non-negative");
        axisSize += sizes[k];
    }
    CV_CheckEQ((size_t)axisSize, (size_t)src.size[axis], "split: the sizes must sum up to the size of the axis");

    int outShape[CV_MAX_DIM];
    for (int i = 0; i < ndims; i++)
        outShape[i] = src.size[i];

    _dst.create(noutputs, 1, type, -1, true);
    AutoBuffer<nd::View, 4> sv(noutputs), dv(noutputs);
    std::vector<Mat> dst(noutputs);
    const nd::View src0 = nd::viewOf(src);
    int ofs = 0;
    for (int k = 0; k < noutputs; k++)
    {
        outShape[axis] = sizes[k];
        _dst.create(ndims, outShape, type, k);
        dst[k] = _dst.getMat(k);
        sv[k] = src0;
        nd::slice(sv[k], axis, ofs, 1, sizes[k]);
        dv[k] = nd::viewOf(dst[k]);
        ofs += sizes[k];
    }
    nd::copyBatch(sv.data(), dv.data(), noutputs);
}

void repeat(InputArray _src, const std::vector<int>& repeats, OutputArray _dst)
{
    CV_INSTRUMENT_REGION();

    Mat src = _src.getMat();
    const int ndims = src.dims;
    CV_Assert(!(ndims == 0 && src.empty()));
    CV_CheckEQ(repeats.size(), (size_t)ndims, "repeat: the number of repeats must match the number of dimensions");

    int outShape[CV_MAX_DIM];
    for (int i = 0; i < ndims; i++)
    {
        CV_CheckGE(repeats[i], 0, "repeat: the repeats must be non-negative");
        int64 sz = (int64)src.size[i]*repeats[i];
        CV_CheckLE((size_t)sz, (size_t)INT_MAX, "repeat: the output is too big");
        outShape[i] = (int)sz;
    }

    _dst.create(ndims, outShape, src.type());
    Mat dst = _dst.getMat();
    if (dst.total() == 0 || src.empty())
        return;

    // Each repeated output axis is split into (repeat index, position), the former
    // with source step 0, so the whole tile is one broadcasting copy.
    nd::View sv, dv;
    sv.data = src.data;
    dv.data = dst.data;
    sv.esz = dv.esz = src.elemSize();
    int n = 0;
    for (int i = 0; i < ndims; i++)
    {
        const int sz = src.size[i], r = repeats[i];
        if (r != 1)
        {
            CV_CheckLT(n, (int)nd::MAX_VIEW_DIMS, "repeat: too many dimensions");
            sv.size[n] = dv.size[n] = r;
            sv.step[n] = 0;
            dv.step[n] = (ptrdiff_t)dst.step[i]*sz;
            n++;
        }
        if (sz != 1 || r == 1)
        {
            CV_CheckLT(n, (int)nd::MAX_VIEW_DIMS, "repeat: too many dimensions");
            sv.size[n] = dv.size[n] = sz;
            sv.step[n] = (ptrdiff_t)src.step[i];
            dv.step[n] = (ptrdiff_t)dst.step[i];
            n++;
        }
    }
    sv.dims = dv.dims = n;
    nd::copy(sv, dv);
}

void slice(InputArray _src, const std::vector<int>& starts, const std::vector<int>& ends,
             const std::vector<int>& steps, OutputArray _dst)
{
    CV_INSTRUMENT_REGION();

    Mat src = _src.getMat();
    const int ndims = src.dims, nslices = (int)starts.size();
    CV_Assert(!(ndims == 0 && src.empty()));
    CV_CheckLE(nslices, ndims, "slice: too many starts");
    CV_CheckEQ(ends.size(), starts.size(), "slice: starts and ends must have the same size");
    CV_Check(steps.size(), steps.empty() || steps.size() == starts.size(),
             "slice: steps must be empty or have the same size as starts");

    nd::View sv = nd::viewOf(src);
    int outShape[CV_MAX_DIM];
    for (int i = 0; i < ndims; i++)
        outShape[i] = src.size[i];

    for (int i = 0; i < nslices; i++)
    {
        const int n = src.size[i], start = starts[i], end = ends[i];
        const int step = steps.empty() ? 1 : steps[i];
        CV_CheckNE(step, 0, "slice: step must not be zero");
        int count;
        if (step > 0)
        {
            CV_Check(start, 0 <= start && start <= n, "slice: start is out of range");
            CV_Check(end, 0 <= end && end <= n, "slice: end is out of range");
            count = end > start ? (int)(((int64)end - start + step - 1)/step) : 0;
        }
        else
        {
            CV_Check(start, -1 <= start && start < n, "slice: start is out of range");
            CV_Check(end, -1 <= end && end < n, "slice: end is out of range");
            count = start > end ? (int)(((int64)start - end - step - 1)/(-step)) : 0;
        }
        nd::slice(sv, i, start, step, count);
        outShape[i] = count;
    }

    _dst.create(ndims, outShape, src.type());
    Mat dst = _dst.getMat();
    if (dst.total() == 0 || src.empty())
        return;
    nd::copy(sv, nd::viewOf(dst));
}

/*
    This function first prepends 1 to each tensor shape to have a common max_ndims dimension, then flatten non-broadcast dimensions.
*/
static bool _flatten_for_broadcast(int narrays, int max_ndims, const int* ndims, const int** orig_shape,
                                   int** flatten_shape, size_t** flatten_step) {
    int i, j, k;

    // step 1.
    // * make all inputs and the output max_ndims-dimensional.
    // * compute proper step's
    for (i = max_ndims - 1; i >= 0; i-- ) {
        for (k = 0; k < narrays; k++) {
            j = ndims[k] - (max_ndims - i);
            int sz_i = j >= 0 ? orig_shape[k][j] : 1;
            size_t st_i = i == max_ndims - 1 ? 1 : flatten_step[k][i+1] * flatten_shape[k][i+1];
            flatten_shape[k][i] = sz_i;
            flatten_step[k][i] = st_i;
            if (flatten_shape[k][i] == 0)
                return false;
        }
    }

    // step 2. Let's do the flattening first,
    // since we'd need proper values of steps to check continuity.
    // this loop is probably the most tricky part
    // in the whole implementation of broadcasting.
    j = max_ndims-1;
    for (i = j - 1; i >= 0; i--) {
        bool all_contiguous = true, all_scalars = true, all_consistent = true;
        for(k = 0; k < narrays; k++) {
            size_t st = flatten_step[k][j] * flatten_shape[k][j];
            bool prev_scalar = flatten_shape[k][j] == 1;
            bool scalar = flatten_shape[k][i] == 1;
            all_contiguous = all_contiguous && (st == flatten_step[k][i]);
            all_scalars = all_scalars && scalar;
            all_consistent = all_consistent && (scalar == prev_scalar);
        }
        if (all_contiguous && (all_consistent || all_scalars)) {
            for(k = 0; k < narrays; k++)
                flatten_shape[k][j] *= flatten_shape[k][i];
        } else {
            j--;
            if (i < j) {
                for(k = 0; k < narrays; k++) {
                    flatten_shape[k][j] = flatten_shape[k][i];
                    flatten_step[k][j] = flatten_step[k][i];
                }
            }
        }
    }

    // step 3. Set some step's to 0's.
    for (i = max_ndims-1; i >= j; i--) {
        for (k = 0; k < narrays; k++)
            flatten_step[k][i] = flatten_shape[k][i] == 1 ? 0 : flatten_step[k][i];
    }
    for (; i >= 0; i--) {
        for (k = 0; k < narrays; k++) {
            flatten_step[k][i] = 0;
            flatten_shape[k][i] = 1;
        }
    }
    return true;
}

void broadcast(InputArray _src, InputArray _shape, OutputArray _dst) {
    CV_INSTRUMENT_REGION();

    Mat src = _src.getMat();
    CV_CheckTrue(src.isContinuous(), "broadcast: input array must be contiguous");
    CV_CheckChannelsEQ(src.channels(), 1, "broadcast: input array must be single channel");

    Mat shape = _shape.getMat();
    CV_CheckTypeEQ(shape.type(), CV_32S, "broadcast: target shape must be of type int32");
    const auto dims_shape = static_cast<int>(shape.total());
    const auto *ptr_shape = shape.ptr<int>();

    // check valid shape, 1D/0D Mat would fail in the following checks
    const auto dims_src = src.dims;
    CV_CheckLE(dims_src, dims_shape,
               "broadcast: dimension of input array must be less than or equal to dimension of target shape");
    std::vector<int> shape_src{src.size.p, src.size.p + dims_src};
    if (shape_src.size() < static_cast<size_t>(dims_shape)) {
        shape_src.insert(shape_src.begin(), dims_shape - shape_src.size(), 1);
    }
    for (int i = 0; i < static_cast<int>(shape_src.size()); ++i) {
        const auto *shape_target = ptr_shape;
        if (shape_src[i] != 1) {
            CV_CheckEQ(shape_src[i], shape_target[i], "target shape must be equal to input shape or 1");
        }
    }

    // impl
    _dst.create(dims_shape, shape.ptr<int>(), src.type());
    Mat dst = _dst.getMat();
    if (dst.total() == 0)
        return;
    cv::AutoBuffer<int> is_same_shape(dims_shape, 0);
    for (int i = 0; i < static_cast<int>(shape_src.size()); ++i) {
        if (shape_src[i] == ptr_shape[i]) {
            is_same_shape[i] = 1;
        }
    }
    // copy if same shape
    if (std::accumulate(is_same_shape.begin(), is_same_shape.end(), 1, std::multiplies<int>()) != 0) {
        const auto *p_src = src.ptr<const char>();
        auto *p_dst = dst.ptr<char>();
        std::memcpy(p_dst, p_src, dst.total() * dst.elemSize());
        return;
    }
    // other cases
    int max_ndims = std::max(dims_src, dims_shape);
    if (max_ndims < 2 && src.total() == 1) {
        const char* p_src = src.ptr<const char>();
        char* p_dst = dst.ptr<char>();
        size_t esz = src.elemSize();
        for (size_t j = 0; j < dst.total(); j++)
            std::memcpy(p_dst + j * esz, p_src, esz);
        return;
    }
    const int all_ndims[2] = {src.dims, dst.dims};
    const int* orig_shapes[2] = {src.size.p, dst.size.p};
    cv::AutoBuffer<size_t> buff(max_ndims * 4);
    int* flatten_shapes[2] = {(int*)buff.data(), (int*)(buff.data() + max_ndims)};
    size_t* flatten_steps[2] = {(size_t*)(buff.data() + 2 * max_ndims), (size_t*)(buff.data() + 3 * max_ndims)};
    if (_flatten_for_broadcast(2, max_ndims, all_ndims, orig_shapes, flatten_shapes, flatten_steps)) {
        size_t src_dp = flatten_steps[0][max_ndims - 1];
        size_t dst_dp = flatten_steps[1][max_ndims - 1];
        CV_Assert(dst_dp == 1 || dst_dp == 0);
        CV_Assert(max_ndims >= 2); // >= 3?
        size_t rowstep_src = flatten_steps[0][max_ndims - 2];
        size_t rowstep_dst = flatten_steps[1][max_ndims - 2];
        const char* ptr_src = src.ptr<const char>();
        char* ptr_dst = dst.ptr<char>();
        size_t esz = src.elemSize();
        int nrows = flatten_shapes[1][max_ndims - 2];
        int ncols = flatten_shapes[1][max_ndims - 1];
        int nplanes = 1;
        CV_Check(esz, esz == 1 || esz == 2 || esz == 4 || esz == 8, "broadcast: not supported data type");

        for (int k = 0; k < max_ndims - 2; k++) {
            nplanes *= flatten_shapes[1][k];
        }
        for (int plane_idx = 0; plane_idx < nplanes; plane_idx++) {
            size_t offset_src = 0, offset_dst = 0;
            size_t idx = (size_t)plane_idx;
            for (int k = max_ndims - 3; k >= 0; k--) {
                size_t prev_idx = idx / flatten_shapes[1][k];
                size_t i_k = (int)(idx - prev_idx * flatten_shapes[1][k]);
                offset_src += i_k * flatten_steps[0][k];
                offset_dst += i_k * flatten_steps[1][k];
                idx = prev_idx;
            }

            #define OPENCV_CORE_BROADCAST_LOOP(_Tp) \
                for (int i = 0; i < nrows; i++) {   \
                    const _Tp *ptr_src_ = (const _Tp*)ptr_src + offset_src + rowstep_src * i; \
                    _Tp *ptr_dst_ = (_Tp*)ptr_dst + offset_dst + rowstep_dst * i; \
                    if (src_dp == 1) { \
                        for (int j = 0; j < ncols; j++) { \
                            ptr_dst_[j] = ptr_src_[j]; \
                        } \
                    } else { \
                        _Tp x = *ptr_src_; \
                        for (int j = 0; j < ncols; j++) { \
                            ptr_dst_[j] = x; \
                        } \
                    } \
                }

            if (esz == 1) {
                OPENCV_CORE_BROADCAST_LOOP(int8_t);
            } else if (esz == 2) {
                OPENCV_CORE_BROADCAST_LOOP(int16_t);
            } else if (esz == 4) {
                OPENCV_CORE_BROADCAST_LOOP(int32_t);
            } else if (esz == 8) {
                OPENCV_CORE_BROADCAST_LOOP(int64_t);
            } else {
                CV_Error(cv::Error::StsNotImplemented, "");
            }
            #undef OPENCV_CORE_BROADCAST_LOOP
        }
    } else {
        if (dst.total() == 0)
            return;
        // initial copy (src to dst)
        std::vector<size_t> step_src{src.step.p, src.step.p + dims_src};
        if (step_src.size() < static_cast<size_t>(dims_shape)) {
            step_src.insert(step_src.begin(), dims_shape - step_src.size(), step_src[0]);
        }
        for (size_t i = 0; i < src.total(); ++i) {
            size_t t = i;
            size_t src_offset = 0, dst_offset = 0;
            for (int j = static_cast<int>(shape_src.size() - 1); j >= 0; --j) {
                size_t idx = t / shape_src[j];
                size_t offset = static_cast<size_t>(t - idx * shape_src[j]);
                src_offset += offset * step_src[j];
                dst_offset += offset * dst.step[j];
                t = idx;
            }
            const auto *p_src = src.ptr<const char>();
            auto *p_dst = dst.ptr<char>();
            std::memcpy(p_dst + dst_offset, p_src + src_offset, dst.elemSize());
        }
        // broadcast copy (dst inplace)
        AutoBuffer<int> cumulative_shape(dims_shape, 1);
        int total = static_cast<int>(dst.total());
        for (int i = dims_shape - 1; i >= 0; --i) {
            cumulative_shape[i] = static_cast<int>(total / ptr_shape[i]);
            total = cumulative_shape[i];
        }
        for (int i = dims_shape - 1; i >= 0; --i) {
            if (is_same_shape[i] == 1) {
                continue;
            }
            auto step = dst.step[i];
            auto *p_dst = dst.ptr<char>();
            for (int j = 0; j < cumulative_shape[i]; j++) {
                for (int k = 0; k < ptr_shape[i] - 1; k++) {
                    std::memcpy(p_dst + step, p_dst, step);
                    p_dst += step;
                }
                p_dst += step;
            }
        }
    }
}

void broadcast(InputArray _src, const MatShape& _shape, OutputArray _dst)
{
    if (_shape.dims < 0) {
        _dst.release();
    } else {
        Mat shape(1, _shape.dims, CV_32S, (int*)_shape.p);
        broadcast(_src, shape, _dst);
    }
}

static void rotateImpl(InputArray _src, OutputArray _dst, int rotateMode)
{
    switch (rotateMode)
    {
    case ROTATE_90_CLOCKWISE:
        transpose(_src, _dst);
        flip(_dst, _dst, 1);
        break;
    case ROTATE_180:
        flip(_src, _dst, -1);
        break;
    case ROTATE_90_COUNTERCLOCKWISE:
        transpose(_src, _dst);
        flip(_dst, _dst, 0);
        break;
    default:
        break;
    }
}

void rotate(InputArray _src, OutputArray _dst, int rotateMode)
{
    CV_Assert(_src.dims() <= 2);
    int angle;

    if (_dst.isUMat())
    {
        rotateImpl(_src, _dst, rotateMode);
        return;
    }

    Mat src = _src.getMat();
    int type = src.type();
    if( src.empty() )
    {
        _dst.release();
        return;
    }

    switch (rotateMode)
    {
    case ROTATE_90_CLOCKWISE:
        _dst.create(src.cols, src.rows, type);
        angle = 90;
        break;
    case ROTATE_180:
        _dst.create(src.rows, src.cols, type);
        angle = 180;
        break;
    case ROTATE_90_COUNTERCLOCKWISE:
        _dst.create(src.cols, src.rows, type);
        angle = 270;
        break;
    default:
        _dst.create(src.rows, src.cols, type);
        angle = 0;
        break;
    }

    Mat dst = _dst.getMat();
    CALL_HAL(rotate90, cv_hal_rotate90, type, src.ptr(), src.step, src.cols, src.rows,
             dst.ptr(), dst.step, angle);

    // use src (Mat) since _src (InputArray) is updated by _dst.create() when in-place
    rotateImpl(src, _dst, rotateMode);
}

}  // namespace
