// This file is part of OpenCV project.
// It is subject to the license terms in the LICENSE file found in the top-level directory
// of this distribution and at http://opencv.org/license.html
// Copyright (C) 2026, BigVision LLC, all rights reserved.
// Third party copyrights are property of their respective owners.


namespace cv {

CV_CPU_OPTIMIZATION_NAMESPACE_BEGIN

void transpose_32bit_blocks_simd(const uchar* src, size_t sstep,
                                 uchar* dst, size_t dstep, Size sz);

#ifndef CV_CPU_OPTIMIZATION_DECLARATIONS_ONLY

static inline void transpose_32bit_blocks_tile(const uint32_t* src32, size_t sstep_e,
                                               uint32_t* dst32, size_t dstep_e,
                                               int i_lo, int i_hi, int j_lo, int j_hi)
{
    int i = i_lo;
    for (; i < i_hi; i++)
        for (int j = j_lo; j < j_hi; j++)
            dst32[dstep_e*i + j] = src32[i + sstep_e*j];
}

void transpose_32bit_blocks_simd(const uchar* src, size_t sstep,
                                 uchar* dst, size_t dstep, Size sz)
{
    const uint32_t* src32 = reinterpret_cast<const uint32_t*>(src);
    uint32_t* dst32 = reinterpret_cast<uint32_t*>(dst);
    const size_t sstep_e = sstep / sizeof(uint32_t);
    const size_t dstep_e = dstep / sizeof(uint32_t);
    const int m = sz.width, n = sz.height;

    // Single-threaded for small inputs to avoid parallel_for_ overhead.
    const int64_t kMinParallelElements = 64 * 1024;
    if ((int64_t)m * n < kMinParallelElements)
    {
        transpose_32bit_blocks_tile(src32, sstep_e, dst32, dstep_e, 0, m, 0, n);
        return;
    }

    const int TILE = 32;
    const int mtiles = (m + TILE - 1) / TILE;
    const int ntiles = (n + TILE - 1) / TILE;
    const int64_t totalTiles = (int64_t)mtiles * ntiles;
    parallel_for_(Range(0, (int)totalTiles), [&](const Range& r)
    {
        for (int idx = r.start; idx < r.end; idx++)
        {
            int ti = idx / ntiles;
            int tj = idx - ti * ntiles;
            int i_lo = ti * TILE, i_hi = std::min(i_lo + TILE, m);
            int j_lo = tj * TILE, j_hi = std::min(j_lo + TILE, n);
            transpose_32bit_blocks_tile(src32, sstep_e, dst32, dstep_e, i_lo, i_hi, j_lo, j_hi);
        }
    });
}

#endif // CV_CPU_OPTIMIZATION_DECLARATIONS_ONLY

CV_CPU_OPTIMIZATION_NAMESPACE_END

} // namespace cv
