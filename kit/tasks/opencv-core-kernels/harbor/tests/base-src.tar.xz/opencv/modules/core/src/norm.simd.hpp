// This file is part of OpenCV project.
// It is subject to the license terms in the LICENSE file found in the top-level directory
// of this distribution and at http://opencv.org/license.html
//
// Copyright (C) 2025, SpaceMIT Inc., all rights reserved.
// Copyright (C) 2026, Advanced Micro Devices, Inc., all rights reserved.
// Third party copyrights are property of their respective owners.

#include "precomp.hpp"

namespace cv {

using NormFunc = int (*)(const uchar*, const uchar*, uchar*, int, int);
using NormDiffFunc = int (*)(const uchar*, const uchar*, const uchar*, uchar*, int, int);

CV_CPU_OPTIMIZATION_NAMESPACE_BEGIN

template<typename T, typename RT, int (*fn)(const T*, const uchar*, RT*, int, int)>
static int normWrap(const uchar* src1, const uchar* src2, uchar* res, int len, int cn)
{
    return fn((const T*)src1, src2, (RT*)res, len, cn);
}

template<typename T, typename RT, int (*fn)(const T*, const T*, const uchar*, RT*, int, int)>
static int normDiffWrap(const uchar* src1, const uchar* src2, const uchar* src3, uchar* res, int len, int cn)
{
    return fn((const T*)src1, (const T*)src2, src3, (RT*)res, len, cn);
}

NormFunc getNormFunc(int normType, int depth);
NormDiffFunc getNormDiffFunc(int normType, int depth);

#ifndef CV_CPU_OPTIMIZATION_DECLARATIONS_ONLY

template <typename T, typename ST>
struct NormInf_SIMD {
    inline ST operator() (const T* src, int n) const {
        ST s = 0;
        for (int i = 0; i < n; i++) {
            s = std::max(s, (ST)cv_abs(src[i]));
        }
        return s;
    }
};

template <typename T, typename ST>
struct NormL1_SIMD {
    inline ST operator() (const T* src, int n) const {
        ST s = 0;
        for (int i = 0; i < n; i++) {
            s += cv_abs(src[i]);
        }
        return s;
    }
};

template <typename T, typename ST>
struct NormL2_SIMD {
    inline ST operator() (const T* src, int n) const {
        ST s = 0;
        for (int i = 0; i < n; i++) {
            ST v = (ST)src[i];
            s += v * v;
        }
        return s;
    }
};

template <typename T, typename ST>
struct NormDiffInf_SIMD {
    inline ST operator() (const T* src1, const T* src2, int n) const {
        ST s = 0;
        for (int i = 0; i < n; i++) {
            ST v = (ST)cv_absdiff(src1[i], src2[i]);
            s = std::max(s, v);
        }
        return s;
    }
};

template <typename T, typename ST>
struct NormDiffL1_SIMD {
    inline ST operator() (const T* src1, const T* src2, int n) const {
        ST s = 0;
        for (int i = 0; i < n; i++) {
            ST v = (ST)cv_absdiff(src1[i], src2[i]);
            s += v;
        }
        return s;
    }
};

template <typename T, typename ST>
struct NormDiffL2_SIMD {
    inline ST operator() (const T* src1, const T* src2, int n) const {
        ST s = 0;
        for (int i = 0; i < n; i++) {
            ST v = (ST)src1[i] - (ST)src2[i];
            s += v * v;
        }
        return s;
    }
};

template <typename T, typename ST>
struct MaskedNormInf_SIMD {
    inline ST operator() (const T* src, const uchar* mask, int len, int cn) const {
        ST s = 0;
        if (cn == 1) {
            for (int i = 0; i < len; i++) {
                if (mask[i]) {
                    s = std::max(s, (ST)cv_abs(src[i]));
                }
            }
        }
        else {
            for (int i = 0; i < len; i++) {
                if (mask[i]) {
                    const T* elem = src + i * cn;
                    int k = 0;
                    for (; k < cn; k++) {
                        s = std::max(s, (ST)cv_abs(elem[k]));
                    }
                }
            }
        }
        return s;
    }
};

template <typename T, typename ST>
struct MaskedNormL1_SIMD {
    inline ST operator() (const T* src, const uchar* mask, int len, int cn) const {
        ST s = 0;
        if (cn == 1) {
            for (int i = 0; i < len; i++) {
                if (mask[i]) {
                    s += (ST)cv_abs(src[i]);
                }
            }
        }
        else {
            for (int i = 0; i < len; i++) {
                if (mask[i]) {
                    const T* elem = src + i * cn;
                    int k = 0;
                    for (; k < cn; k++) {
                        s += (ST)cv_abs(elem[k]);
                    }
                }
            }
        }
        return s;
    }
};

template <typename T, typename ST>
struct MaskedNormL2_SIMD {
    inline ST operator() (const T* src, const uchar* mask, int len, int cn) const {
        ST s = 0;
        if (cn == 1) {
            int i = 0;
            for (; i < len; i++) {
                if (mask[i]) {
                    T v = src[i];
                    s += (ST)v * v;
                }
            }
        }
        else {
            for (int i = 0; i < len; i++) {
                if (mask[i]) {
                    const T* elem = src + i * cn;
                    int k = 0;
                    for (; k < cn; k++) {
                        T v = elem[k];
                        s += (ST)v * v;
                    }
                }
            }
        }

        return s;
    }
};

template<typename T, typename ST> int
normInf_(const T* src, const uchar* mask, ST* _result, int len, int cn)
{
    ST result = *_result;
    if( !mask )
    {
        NormInf_SIMD<T, ST> op;
        result = std::max(result, op(src, len*cn));
    } else {
        MaskedNormInf_SIMD<T, ST> op;
        result = std::max(result, op(src, mask, len, cn));
    }
    *_result = result;
    return 0;
}

template<typename T, typename ST> int
normL1_(const T* src, const uchar* mask, ST* _result, int len, int cn)
{
    ST result = *_result;
    if( !mask )
    {
        NormL1_SIMD<T, ST> op;
        result += op(src, len*cn);
    } else {
        MaskedNormL1_SIMD<T, ST> op;
        result += op(src, mask, len, cn);
    }
    *_result = result;
    return 0;
}

template<typename T, typename ST> int
normL2_(const T* src, const uchar* mask, ST* _result, int len, int cn)
{
    ST result = *_result;
    if( !mask )
    {
        NormL2_SIMD<T, ST> op;
        result += op(src, len*cn);
    }
    else
    {
        MaskedNormL2_SIMD<T, ST> op;
        result += op(src, mask, len, cn);
    }
    *_result = result;
    return 0;
}

static int
normInf_Bool(const uchar* src, const uchar* mask, int* _result, int len, int cn)
{
    int result = *_result;
    if( !mask )
    {
        for ( int i = 0; i < len*cn; i++ ) {
            result = std::max(result, (int)(src[i] != 0));
            if (result != 0)
                break;
        }
    }
    else
    {
        for( int i = 0; i < len; i++, src += cn )
            if( mask[i] )
            {
                for( int k = 0; k < cn; k++ )
                    result = std::max(result, (int)(src[k] != 0));
                if (result != 0)
                    break;
            }
    }
    *_result = result;
    return 0;
}

static int
normL1_Bool(const uchar* src, const uchar* mask, int* _result, int len, int cn)
{
    int result = *_result;
    if( !mask )
    {
        for ( int i = 0; i < len*cn; i++ )
            result += (int)(src[i] != 0);
    }
    else
    {
        for( int i = 0; i < len; i++, src += cn )
            if( mask[i] )
            {
                for( int k = 0; k < cn; k++ )
                    result += (int)(src[k] != 0);
            }
    }
    *_result = result;
    return 0;
}

static int
normL2_Bool(const uchar* src, const uchar* mask, int* _result, int len, int cn)
{
    return normL1_Bool(src, mask, _result, len, cn);
}

// ====================================================================
// Masked norm-diff kernels.
// Scalar base templates (safe for every depth) plus SIMD cn==1
// specializations for the concrete (T, ST) pairs dispatched by
// CV_DEF_NORM_ALL. The masked normDiff*_ functions below select them.
// ====================================================================
template <typename T, typename ST>
struct MaskedNormDiffInf_SIMD {
    inline ST operator()(const T* s1, const T* s2, const uchar* mask, int len, int cn) const {
        ST result = 0;
        for (int i = 0; i < len; i++) if (mask[i]) {
            const T* e1 = s1 + i*cn; const T* e2 = s2 + i*cn;
            for (int k = 0; k < cn; k++)
                result = std::max(result, (ST)cv_absdiff(e1[k], e2[k]));
        }
        return result;
    }
};
template <typename T, typename ST>
struct MaskedNormDiffL1_SIMD {
    inline ST operator()(const T* s1, const T* s2, const uchar* mask, int len, int cn) const {
        ST result = 0;
        for (int i = 0; i < len; i++) if (mask[i]) {
            const T* e1 = s1 + i*cn; const T* e2 = s2 + i*cn;
            for (int k = 0; k < cn; k++)
                result += (ST)cv_absdiff(e1[k], e2[k]);
        }
        return result;
    }
};
template <typename T, typename ST>
struct MaskedNormDiffL2_SIMD {
    inline ST operator()(const T* s1, const T* s2, const uchar* mask, int len, int cn) const {
        ST result = 0;
        for (int i = 0; i < len; i++) if (mask[i]) {
            const T* e1 = s1 + i*cn; const T* e2 = s2 + i*cn;
            for (int k = 0; k < cn; k++) { ST v = (ST)e1[k] - (ST)e2[k]; result += v*v; }
        }
        return result;
    }
};

template<typename T, typename ST> int
normDiffInf_(const T* src1, const T* src2, const uchar* mask, ST* _result, int len, int cn) {
    ST result = *_result;
    if( !mask ) {
        NormDiffInf_SIMD<T, ST> op;
        result = std::max(result, op(src1, src2, len*cn));
    } else {
        MaskedNormDiffInf_SIMD<T, ST> op;
        result = std::max(result, op(src1, src2, mask, len, cn));
    }
    *_result = result;
    return 0;
}

template<typename T, typename ST> int
normDiffL1_(const T* src1, const T* src2, const uchar* mask, ST* _result, int len, int cn) {
    ST result = *_result;
    if( !mask ) {
        NormDiffL1_SIMD<T, ST> op;
        result += op(src1, src2, len*cn);
    } else {
        MaskedNormDiffL1_SIMD<T, ST> op;
        result += op(src1, src2, mask, len, cn);
    }
    *_result = result;
    return 0;
}

template<typename T, typename ST> int
normDiffL2_(const T* src1, const T* src2, const uchar* mask, ST* _result, int len, int cn) {
    ST result = *_result;
    if( !mask ) {
        NormDiffL2_SIMD<T, ST> op;
        result += op(src1, src2, len*cn);
    } else {
        MaskedNormDiffL2_SIMD<T, ST> op;
        result += op(src1, src2, mask, len, cn);
    }
    *_result = result;
    return 0;
}

static int
normDiffInf_Bool(const uchar* src1, const uchar* src2, const uchar* mask, int* _result, int len, int cn)
{
    int result = *_result;
    if( !mask )
    {
        for( int i = 0; i < len*cn; i++ ) {
            result = std::max(result, (int)((src1[i] != 0) != (src2[i] != 0)));
            if (result != 0)
                break;
        }
    }
    else
    {
        for( int i = 0; i < len; i++, src1 += cn, src2 += cn )
            if( mask[i] )
            {
                for( int k = 0; k < cn; k++ )
                    result = std::max(result, (int)((src1[k] != 0) != (src2[k] != 0)));
                if (result != 0)
                    break;
            }
    }
    *_result = result;
    return 0;
}

static int
normDiffL1_Bool(const uchar* src1, const uchar* src2, const uchar* mask, int* _result, int len, int cn)
{
    int result = *_result;
    if( !mask )
    {
        for( int i = 0; i < len*cn; i++ )
            result += (int)((src1[i] != 0) != (src2[i] != 0));
    }
    else
    {
        for( int i = 0; i < len; i++, src1 += cn, src2 += cn )
            if( mask[i] )
            {
                for( int k = 0; k < cn; k++ )
                    result += (int)((src1[k] != 0) != (src2[k] != 0));
            }
    }
    *_result = result;
    return 0;
}

static int
normDiffL2_Bool(const uchar* src1, const uchar* src2, const uchar* mask, int* _result, int len, int cn)
{
    return normDiffL1_Bool(src1, src2, mask, _result, len, cn);
}

#define CV_DEF_NORM_FUNC(L, suffix, type, ntype) \
    static int norm##L##_##suffix(const type* src, const uchar* mask, ntype* r, int len, int cn) \
{ CV_INSTRUMENT_REGION(); return norm##L##_(src, mask, r, len, cn); } \
    static int normDiff##L##_##suffix(const type* src1, const type* src2, \
    const uchar* mask, ntype* r, int len, int cn) \
{ return normDiff##L##_(src1, src2, mask, r, (int)len, cn); }

#define CV_DEF_NORM_ALL(suffix, type, inftype, l1type, l2type) \
    CV_DEF_NORM_FUNC(Inf, suffix, type, inftype) \
    CV_DEF_NORM_FUNC(L1, suffix, type, l1type) \
    CV_DEF_NORM_FUNC(L2, suffix, type, l2type)

CV_DEF_NORM_ALL(8u, uchar, int, int, int)
CV_DEF_NORM_ALL(8s, schar, int, int, int)
CV_DEF_NORM_ALL(16u, ushort, int, int, double)
CV_DEF_NORM_ALL(16s, short, int, int, double)
CV_DEF_NORM_ALL(32u, unsigned, unsigned, double, double)
CV_DEF_NORM_ALL(32s, int, unsigned, double, double)
CV_DEF_NORM_ALL(32f, float, float, double, double)
CV_DEF_NORM_ALL(64f, double, double, double, double)
CV_DEF_NORM_ALL(64u, uint64, uint64, double, double)
CV_DEF_NORM_ALL(64s, int64, uint64, double, double)
CV_DEF_NORM_ALL(16f, hfloat, float, float, float)
CV_DEF_NORM_ALL(16bf, bfloat, float, float, float)

NormFunc getNormFunc(int normType, int depth)
{
    CV_INSTRUMENT_REGION();

    static NormFunc normTab[3][CV_DEPTH_MAX] =
    {
        {
            normWrap<uchar, int, normInf_8u>,
            normWrap<schar, int, normInf_8s>,
            normWrap<ushort, int, normInf_16u>,
            normWrap<short, int, normInf_16s>,
            normWrap<int, unsigned, normInf_32s>,
            normWrap<float, float, normInf_32f>,
            normWrap<double, double, normInf_64f>,
            normWrap<hfloat, float, normInf_16f>,
            normWrap<bfloat, float, normInf_16bf>,
            normWrap<uchar, int, normInf_Bool>,
            normWrap<uint64, uint64, normInf_64u>,
            normWrap<int64, uint64, normInf_64s>,
            normWrap<unsigned, unsigned, normInf_32u>,
            0
        },
        {
            normWrap<uchar, int, normL1_8u>,
            normWrap<schar, int, normL1_8s>,
            normWrap<ushort, int, normL1_16u>,
            normWrap<short, int, normL1_16s>,
            normWrap<int, double, normL1_32s>,
            normWrap<float, double, normL1_32f>,
            normWrap<double, double, normL1_64f>,
            normWrap<hfloat, float, normL1_16f>,
            normWrap<bfloat, float, normL1_16bf>,
            normWrap<uchar, int, normL1_Bool>,
            normWrap<uint64, double, normL1_64u>,
            normWrap<int64, double, normL1_64s>,
            normWrap<unsigned, double, normL1_32u>,
            0
        },
        {
            normWrap<uchar, int, normL2_8u>,
            normWrap<schar, int, normL2_8s>,
            normWrap<ushort, double, normL2_16u>,
            normWrap<short, double, normL2_16s>,
            normWrap<int, double, normL2_32s>,
            normWrap<float, double, normL2_32f>,
            normWrap<double, double, normL2_64f>,
            normWrap<hfloat, float, normL2_16f>,
            normWrap<bfloat, float, normL2_16bf>,
            normWrap<uchar, int, normL2_Bool>,
            normWrap<uint64, double, normL2_64u>,
            normWrap<int64, double, normL2_64s>,
            normWrap<unsigned, double, normL2_32u>,
            0
        }
    };

    if (normType >= 3 || normType < 0) return nullptr;

    return normTab[normType][depth];
}

NormDiffFunc getNormDiffFunc(int normType, int depth)
{
    static NormDiffFunc normDiffTab[3][CV_DEPTH_MAX] =
    {
        {
            normDiffWrap<uchar, int, normDiffInf_8u>,
            normDiffWrap<schar, int, normDiffInf_8s>,
            normDiffWrap<ushort, int, normDiffInf_16u>,
            normDiffWrap<short, int, normDiffInf_16s>,
            normDiffWrap<int, unsigned, normDiffInf_32s>,
            normDiffWrap<float, float, normDiffInf_32f>,
            normDiffWrap<double, double, normDiffInf_64f>,
            normDiffWrap<hfloat, float, normDiffInf_16f>,
            normDiffWrap<bfloat, float, normDiffInf_16bf>,
            normDiffWrap<uchar, int, normDiffInf_Bool>,
            normDiffWrap<uint64, uint64, normDiffInf_64u>,
            normDiffWrap<int64, uint64, normDiffInf_64s>,
            normDiffWrap<unsigned, unsigned, normDiffInf_32u>,
            0
        },
        {
            normDiffWrap<uchar, int, normDiffL1_8u>,
            normDiffWrap<schar, int, normDiffL1_8s>,
            normDiffWrap<ushort, int, normDiffL1_16u>,
            normDiffWrap<short, int, normDiffL1_16s>,
            normDiffWrap<int, double, normDiffL1_32s>,
            normDiffWrap<float, double, normDiffL1_32f>,
            normDiffWrap<double, double, normDiffL1_64f>,
            normDiffWrap<hfloat, float, normDiffL1_16f>,
            normDiffWrap<bfloat, float, normDiffL1_16bf>,
            normDiffWrap<uchar, int, normDiffL1_Bool>,
            normDiffWrap<uint64, double, normDiffL1_64u>,
            normDiffWrap<int64, double, normDiffL1_64s>,
            normDiffWrap<unsigned, double, normDiffL1_32u>,
            0
        },
        {
            normDiffWrap<uchar, int, normDiffL2_8u>,
            normDiffWrap<schar, int, normDiffL2_8s>,
            normDiffWrap<ushort, double, normDiffL2_16u>,
            normDiffWrap<short, double, normDiffL2_16s>,
            normDiffWrap<int, double, normDiffL2_32s>,
            normDiffWrap<float, double, normDiffL2_32f>,
            normDiffWrap<double, double, normDiffL2_64f>,
            normDiffWrap<hfloat, float, normDiffL2_16f>,
            normDiffWrap<bfloat, float, normDiffL2_16bf>,
            normDiffWrap<uchar, int, normDiffL2_Bool>,
            normDiffWrap<uint64, double, normDiffL2_64u>,
            normDiffWrap<int64, double, normDiffL2_64s>,
            normDiffWrap<unsigned, double, normDiffL2_32u>,
            0
        },
    };
    if (normType >= 3 || normType < 0) return nullptr;

    return normDiffTab[normType][depth];
}

#endif // CV_CPU_OPTIMIZATION_DECLARATIONS_ONLY

CV_CPU_OPTIMIZATION_NAMESPACE_END

} // cv::
