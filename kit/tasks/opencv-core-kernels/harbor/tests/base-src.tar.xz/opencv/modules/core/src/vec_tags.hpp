// This file is part of OpenCV project.
// It is subject to the license terms in the LICENSE file found in the top-level directory
// of this distribution and at http://opencv.org/license.html

// Work-type tags for the element-wise kernel templates. This tree is built without vector code:
// a tag only names the scalar lane type that a kernel template computes in.
#ifndef OPENCV_CORE_SRC_VEC_TAGS_HPP
#define OPENCV_CORE_SRC_VEC_TAGS_HPP

namespace cv {

template<typename T> struct lane_tag { typedef T lane_type; };

typedef lane_tag<uchar>    v_uint8;
typedef lane_tag<schar>    v_int8;
typedef lane_tag<ushort>   v_uint16;
typedef lane_tag<short>    v_int16;
typedef lane_tag<unsigned> v_uint32;
typedef lane_tag<int>      v_int32;
typedef lane_tag<uint64>   v_uint64;
typedef lane_tag<int64>    v_int64;
typedef lane_tag<float>    v_float32;
typedef lane_tag<double>   v_float64;

template<typename V> struct VTraits
{
    typedef typename V::lane_type lane_type;
    static int vlanes() { return 1; }
};

} // namespace cv

#endif
