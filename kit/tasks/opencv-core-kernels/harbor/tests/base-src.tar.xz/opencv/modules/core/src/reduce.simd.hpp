// This file is part of OpenCV project.
// It is subject to the license terms in the LICENSE file found in the top-level directory
// of this distribution and at http://opencv.org/license.html

#include "precomp.hpp"

namespace cv {
CV_CPU_OPTIMIZATION_NAMESPACE_BEGIN

typedef void (*ReduceSumFunc)(const Mat& src, Mat& dst);
ReduceSumFunc getReduceCSumFunc(int sdepth, int ddepth);
ReduceSumFunc getReduceRSumFunc(int sdepth, int ddepth);
ReduceSumFunc getReduceRSum2Func(int sdepth, int ddepth);

#ifndef CV_CPU_OPTIMIZATION_DECLARATIONS_ONLY

// =====================================================================
//  Col reduce SUM (dim=1): sum each row into cn output values
// =====================================================================

// =====================================================================
//  Dispatchers
// =====================================================================

ReduceSumFunc getReduceCSumFunc(int sdepth, int ddepth)
{
    CV_UNUSED(sdepth);
    CV_UNUSED(ddepth);
    return nullptr;
}

ReduceSumFunc getReduceRSumFunc(int sdepth, int ddepth)
{
    CV_UNUSED(sdepth);
    CV_UNUSED(ddepth);
    return nullptr;
}

ReduceSumFunc getReduceRSum2Func(int sdepth, int ddepth)
{
    CV_UNUSED(sdepth);
    CV_UNUSED(ddepth);
    return nullptr;
}

#endif // CV_CPU_OPTIMIZATION_DECLARATIONS_ONLY

CV_CPU_OPTIMIZATION_NAMESPACE_END
} // namespace cv
