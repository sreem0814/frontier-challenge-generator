// This file is part of OpenCV project.
// It is subject to the license terms in the LICENSE file found in the top-level directory
// of this distribution and at http://opencv.org/license.html


#include "precomp.hpp"

namespace cv {

typedef void (*PatchNanFunc)(uchar* tptr, size_t len, double newVal);
typedef void (*FiniteMaskFunc)(const uchar *src, uchar *dst, size_t total);

CV_CPU_OPTIMIZATION_NAMESPACE_BEGIN

PatchNanFunc getPatchNanFunc(bool isDouble);
FiniteMaskFunc getFiniteMaskFunc(bool isDouble, int cn);

#ifndef CV_CPU_OPTIMIZATION_DECLARATIONS_ONLY

static void patchNaNs_32f(uchar* ptr, size_t ulen, double newVal)
{
    CV_INSTRUMENT_REGION();

    int32_t* tptr = (int32_t*)ptr;
    Cv32suf val;
    val.f = (float)newVal;

    int j = 0;
    int len = (int)ulen;

    for (; j < len; j++)
    {
        if ((tptr[j] & 0x7fffffff) > 0x7f800000)
        {
            tptr[j] = val.i;
        }
    }
}


static void patchNaNs_64f(uchar* ptr, size_t ulen, double newVal)
{
    CV_INSTRUMENT_REGION();

    int64_t* tptr = (int64_t*)ptr;
    Cv64suf val;
    val.f = newVal;

    int j = 0;
    int len = (int)ulen;

    for (; j < len; j++)
        if ((tptr[j] & 0x7FFFFFFFFFFFFFFF) > 0x7FF0000000000000)
            tptr[j] = val.i;
}

PatchNanFunc getPatchNanFunc(bool isDouble)
{
    return isDouble ? patchNaNs_64f
                    : patchNaNs_32f;
}

////// finiteMask //////


template <typename _Tp, int cn>
void finiteMask_(const uchar *src, uchar *dst, size_t total)
{
    CV_INSTRUMENT_REGION();
    size_t i = 0;
    const _Tp* tsrc = (const _Tp*) src;

    for(; i < total; i++ )
    {
        bool finite = true;
        for (int c = 0; c < cn; c++)
        {
            _Tp val = tsrc[i * cn + c];
            finite = finite && !cvIsNaN(val) && !cvIsInf(val);
        }
        dst[i] = finite ? 255 : 0;
    }
}

FiniteMaskFunc getFiniteMaskFunc(bool isDouble, int cn)
{
    static FiniteMaskFunc tab[CV_DEPTH_MAX] =
    {
        finiteMask_<float,  1>,
        finiteMask_<float,  2>,
        finiteMask_<float,  3>,
        finiteMask_<float,  4>,
        finiteMask_<double, 1>,
        finiteMask_<double, 2>,
        finiteMask_<double, 3>,
        finiteMask_<double, 4>,
    };

    int idx = (isDouble ? 4 : 0) + cn - 1;
    return tab[idx];
}

#endif
CV_CPU_OPTIMIZATION_NAMESPACE_END
} // namespace cv
