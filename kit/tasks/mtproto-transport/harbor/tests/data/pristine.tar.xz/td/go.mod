module github.com/gotd/td

go 1.25.0

require (
	github.com/awnumar/memguard v0.23.0
	github.com/beevik/ntp v1.5.0
	github.com/cenkalti/backoff/v4 v4.3.0
	github.com/coder/websocket v1.8.15
	github.com/go-faster/errors v0.8.0
	github.com/go-faster/jx v1.2.0
	github.com/go-faster/xor v1.0.0
	github.com/go-openapi/inflect v1.0.0
	github.com/google/uuid v1.6.0
	github.com/gotd/getdoc v0.53.0
	github.com/gotd/ige v0.3.0
	github.com/gotd/log v0.1.0
	github.com/gotd/log/logzap v0.1.1
	github.com/gotd/neo v0.1.5
	github.com/gotd/tl v0.4.0
	github.com/k0kubun/pp/v3 v3.5.2
	github.com/klauspost/compress v1.19.1
	github.com/ogen-go/ogen v1.23.0
	github.com/pion/ice/v4 v4.4.0
	github.com/pion/interceptor v0.1.47
	github.com/pion/logging v0.2.4
	github.com/pion/rtcp v1.2.17
	github.com/pion/rtp v1.10.5
	github.com/pion/transport/v4 v4.0.2
	github.com/pion/webrtc/v4 v4.2.18
	github.com/refraction-networking/utls v1.8.2
	github.com/rogpeppe/go-internal v1.15.0
	github.com/stretchr/testify v1.11.1
	github.com/yuin/goldmark v1.8.5
	go.opentelemetry.io/otel v1.44.0
	go.opentelemetry.io/otel/metric v1.44.0
	go.opentelemetry.io/otel/trace v1.44.0
	go.uber.org/atomic v1.11.0
	go.uber.org/multierr v1.11.0
	go.uber.org/zap v1.28.0
	golang.org/x/crypto v0.54.0
	golang.org/x/net v0.57.0
	golang.org/x/sync v0.22.0
	golang.org/x/tools v0.48.0
	gopkg.in/yaml.v3 v3.0.1
	nhooyr.io/websocket v1.8.17
	rsc.io/qr v0.2.0
)

require (
	github.com/PuerkitoBio/goquery v1.11.0 // indirect
	github.com/andybalholm/brotli v1.2.1 // indirect
	github.com/andybalholm/cascadia v1.3.3 // indirect
	github.com/awnumar/memcall v0.4.0 // indirect
	github.com/benbjohnson/clock v1.3.0 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/dlclark/regexp2 v1.12.0 // indirect
	github.com/fatih/color v1.19.0 // indirect
	github.com/ghodss/yaml v1.0.0 // indirect
	github.com/go-faster/sdk v0.34.0 // indirect
	github.com/go-faster/yaml v0.4.6 // indirect
	github.com/go-logr/logr v1.4.3 // indirect
	github.com/go-logr/stdr v1.2.2 // indirect
	github.com/mattn/go-colorable v0.1.15 // indirect
	github.com/mattn/go-isatty v0.0.22 // indirect
	github.com/pion/datachannel v1.6.2 // indirect
	github.com/pion/dtls/v3 v3.1.5 // indirect
	github.com/pion/mdns/v2 v2.1.0 // indirect
	github.com/pion/randutil v0.1.0 // indirect
	github.com/pion/sctp v1.11.1 // indirect
	github.com/pion/sdp/v3 v3.0.19 // indirect
	github.com/pion/srtp/v3 v3.0.12 // indirect
	github.com/pion/stun/v3 v3.1.6 // indirect
	github.com/pion/turn/v5 v5.0.12 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	github.com/segmentio/asm v1.2.1 // indirect
	github.com/sergi/go-diff v1.1.0 // indirect
	github.com/shopspring/decimal v1.4.0 // indirect
	github.com/wlynxg/anet v0.0.5 // indirect
	go.opentelemetry.io/auto/sdk v1.2.1 // indirect
	go.uber.org/ratelimit v0.3.1 // indirect
	golang.org/x/exp v0.0.0-20230725093048-515e97ebf090 // indirect
	golang.org/x/mod v0.38.0 // indirect
	golang.org/x/sys v0.47.0 // indirect
	golang.org/x/text v0.40.0 // indirect
	golang.org/x/time v0.14.0 // indirect
	gopkg.in/yaml.v2 v2.4.0 // indirect
)
